/*
 * Name:
 * Date Submitted:
 * Lab Section:
 * Assignment Name:
 */

#pragma once

#include <vector>

template <class T>
std::vector<T> mergeSort(std::vector<T> lst){
}

template <class T>
std::vector<T> quickSort(std::vector<T> lst){
}
