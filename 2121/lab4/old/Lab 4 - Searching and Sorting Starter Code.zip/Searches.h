/*
 * Name:
 * Date Submitted:
 * Lab Section:
 * Assignment Name:
 */

#pragma once

#include <vector>

template <class T>
int linearSearch(std::vector<T> data, T target){
}


template <class T>
int binarySearch(std::vector<T> data, T target){
}
